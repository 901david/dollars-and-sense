import { createConnection } from 'mysql2';

exports.handler = (event, context, callback) => {
  const DB_CONNECTION = createConnection(process.env.JAWSDB_URL);

  DB_CONNECTION.query(
    `UPDATE Users SET email_confirmed=true WHERE id=${event.id}`,
    (err, results) => {
      if (error) {
        callback(error, undefined);
      }
      callback(undefined, { status: 200, message: 'Email Confirmed.' });
    }
  );
};
